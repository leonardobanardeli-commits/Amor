# Como trocar as fotos

As imagens `foto1.jpg` até `foto6.jpg` nesta pasta são **placeholders**
gerados automaticamente (fundo escuro com um coração dourado), só para você
ver o layout da galeria funcionando.

## Para usar suas fotos de verdade

1. Escolha até 6 fotos suas (funciona melhor com fotos verticais ou quadradas).
2. Renomeie cada uma para `foto1.jpg`, `foto2.jpg`, `foto3.jpg`, etc.
3. Substitua os arquivos desta pasta pelos seus.
4. Pronto — a galeria e o lightbox atualizam automaticamente.

## Para usar mais ou menos de 6 fotos, ou outros nomes de arquivo

Edite a lista `fotos:` dentro do objeto `CONFIG`, no arquivo `script.js`
(na raiz do projeto):

```js
fotos: [
  "assets/images/foto1.jpg",
  "assets/images/foto2.jpg",
  // adicione ou remova linhas aqui
],
```

## Fotos na "Nossa história" (timeline)

Cada item da timeline também aceita uma foto opcional. Edite o campo `foto`
de cada item dentro de `historia:` no mesmo `CONFIG`, por exemplo:

```js
foto: "assets/images/foto1.jpg"
```

Deixe `foto: ""` (vazio) se não quiser mostrar foto naquele item.
