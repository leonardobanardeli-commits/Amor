# Como adicionar a música

1. Escolha uma música que **você tenha autorização para usar** (por exemplo, uma
   música sua, livre de direitos autorais, ou comprada/licenciada para esse uso).
2. Renomeie o arquivo para: `nossa-musica.mp3`
3. Coloque o arquivo exatamente nesta pasta: `assets/music/nossa-musica.mp3`
4. Se quiser usar outro nome de arquivo, edite a linha `musica:` dentro do
   objeto `CONFIG` no arquivo `script.js` (na raiz do projeto).
5. (Opcional) Edite `nomeMusica:` no mesmo `CONFIG` para mostrar o nome da
   música no player.

⚠️ Não foi incluída nenhuma música no projeto por padrão, para respeitar
direitos autorais. O site funciona normalmente sem o arquivo — o player
apenas mostrará um aviso até você adicionar o mp3.
